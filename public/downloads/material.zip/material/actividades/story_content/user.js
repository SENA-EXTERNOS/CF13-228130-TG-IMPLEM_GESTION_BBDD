function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6QS1jmj2nvv":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

